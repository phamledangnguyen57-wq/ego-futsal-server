EGO FUTSAL 3D — BO MAY CHU TRUNG TAM (PHASE 1)

QUAN TRONG: Ban KHONG can mo server.js bang cach nhap dup.
server.js la ma nguon chay bang Node.js, khong phai giao dien game.
Cach de nhat: giai nen ZIP, cai Node.js 20+ neu chua co, roi bam dup START-SERVER.bat.

TRONG GOI CO
- Ego-Futsal-Neutral-Server.html : file game.
- server.js : tien trinh may chu Node.js.
- server.js.txt : ban sao de tai/mo bang Notepad; neu can, doi ten thanh server.js.
- package.json : lenh khoi dong.
- START-SERVER.bat : bam dup de khoi dong tren Windows.

BAT DAU TREN WINDOWS
1. Giai nen TOAN BO ZIP vao mot thu muc, vi du Desktop\\EgoFutsalServer.
2. Cai Node.js LTS ban 20 tro len tu https://nodejs.org/ neu may chua co.
3. Bam dup START-SERVER.bat.
4. Cua so den (CMD) se mo va giu may chu dang chay. Khong dong cua so nay khi dang choi.
5. Trinh duyet mo trang trang thai: http://localhost:3000/status.
6. Mo game tai: http://localhost:3000/.
7. May khac cung Wi-Fi co the thu: http://DIA-CHI-IP-LAN-CUA-MAY-CHU:3000/.
   Can cho phep Node.js qua Windows Firewall khi duoc hoi.

NEU WINDOWS AN DUOI MO RONG FILE
Khong can mo server.js. Chi can bam START-SERVER.bat.
Neu tai rieng server.js.txt, co the giu nguyen de doc bang Notepad; chi doi ten thanh server.js neu tu chay bang lenh.

CHOI QUA INTERNET / VPS SINGAPORE
Bo file nay chua tu tao VPS hay dia chi cong khai. Can mot VPS that (uu tien Singapore),
Node.js 20+, IP/domain cong khai, HTTPS/WSS va cau hinh firewall/reverse proxy phu hop.
Sau khi trien khai, ca hai may phai mo CUNG mot URL HTTPS cua VPS.

GIOI HAN QUAN TRONG CUA PHASE 1
Server hien quan ly ma phong, heartbeat va chuyen tiep du lieu nho. Vat ly bong,
AI, va cham va ban thang van chay tren may chu phong. Day CHUA phai authoritative
game server hoan chinh. Chua co VPS Singapore duoc thue va cau hinh san.
