@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ===============================================
echo        EGO FUTSAL - MAY CHU TRUNG TAM
echo ===============================================
where node >nul 2>nul
if errorlevel 1 (
  echo Khong tim thay Node.js.
  echo Hay cai Node.js LTS ban 20 tro len tai https://nodejs.org/
  echo Sau khi cai dat, dong cua so nay va bam lai START-SERVER.bat.
  pause
  exit /b 1
)
start "Ego Futsal - Trang thai may chu" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:3000/status"
echo Dang khoi dong may chu...
echo Game:       http://localhost:3000/
echo Trang thai: http://localhost:3000/status
echo Health API: http://localhost:3000/health
echo Nhan Ctrl+C de dung may chu.
node server.js
 echo.
echo May chu da dung. Nhan phim bat ky de dong cua so.
pause >nul
